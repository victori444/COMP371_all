#include <json.hpp>

class RayTracer {
    public:
        RayTracer(nlohmann::json& j);
        void run();
    private:
        nlohmann::json& sourceFile;
};