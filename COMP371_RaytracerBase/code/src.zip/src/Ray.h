#include <Eigen/Dense>

class Ray 
{
    public:
        Ray(Eigen::Vector3d directionIn, Eigen::Vector3d originIn);

        inline Eigen::Vector3d getDirection() const ( return direction; )
        inline Eigen::Vector3d getOrigin() const ( return origin; )

        // check where a point is along a ray at param t
        Eigen::Vector3d getPointAtT(float t);

    private:
        Eigen::Vector3d direction;
        Eigen::Vector3d origin;
}