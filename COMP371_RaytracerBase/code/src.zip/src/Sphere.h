#include <Eigen/Dense>

class Sphere : public Geometry {

    public:

        Sphere(const Eigen::Vector3d centerIn, float radiusIn);
        Vector3d getCenter() const { return center; }
        float getRadius() const { return radius; }

        // does it intersect
        bool tryIntersectRay(const Ray &r, double& t);

    private:
        Eigen::Vector3d center;
        float radius;
}